#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Google Cloud Function לעדכון תוצאות לוטו
"""

import functions_framework
from lottery_scraper_cloud import LotteryScraperCloud
import logging
import json
import os
from datetime import datetime

logging.basicConfig(level=logging.INFO, format='%(asctime)s - %(levelname)s - %(message)s')
logger = logging.getLogger(__name__)

@functions_framework.http
def lottery_scraper_function(request):
    """HTTP Cloud Function for lottery data scraping.
    Args:
        request (flask.Request): The request object.
    Returns:
        JSON response with success status and details.
    """
    logger.info("Cloud Function triggered: Starting lottery data update.")
    
    try:
        # יצירת instance של הסקריפט
        scraper = LotteryScraperCloud()
        
        # הרצת הסקריפט
        success = scraper.run()
        
        if success:
            # קריאת הסטטיסטיקות שנוצרו
            stats_data = {}
            if os.path.exists('lottery_stats.json'):
                with open('lottery_stats.json', 'r', encoding='utf-8') as f:
                    stats_data = json.load(f)
            
            response_data = {
                "success": True,
                "message": "Lottery data updated successfully.",
                "stats": stats_data,
                "timestamp": datetime.now().strftime('%d/%m/%Y %H:%M:%S')
            }
            
            logger.info("Lottery data update completed successfully.")
            return json.dumps(response_data, ensure_ascii=False), 200, {'Content-Type': 'application/json; charset=utf-8'}
        else:
            logger.warning("Lottery data update completed but no new data was added.")
            return json.dumps({
                "success": True,
                "message": "No new lottery data found - file not updated.",
                "timestamp": datetime.now().strftime('%d/%m/%Y %H:%M:%S')
            }, ensure_ascii=False), 200, {'Content-Type': 'application/json; charset=utf-8'}
            
    except Exception as e:
        logger.error(f"Error in Cloud Function: {e}")
        return json.dumps({
            "success": False,
            "message": f"An error occurred: {str(e)}"
        }, ensure_ascii=False), 500, {'Content-Type': 'application/json; charset=utf-8'}

# פונקציה נוספת לתזמון אוטומטי
@functions_framework.http
def scheduled_lottery_update(request):
    """
    פונקציה שתרוץ על תזמון אוטומטי
    """
    return lottery_scraper_function(request)